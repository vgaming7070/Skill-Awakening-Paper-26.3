package com.vgaming70.skillawakening;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public final class SkillAwakeningPlugin extends JavaPlugin implements Listener {
    private static final String MENU_TITLE = "§5Skill Awakening Codex";
    private static final String ADMIN_TITLE = "§4Mythical Administration";
    private final List<String> allSkills = List.of(
        "Dash", "Stone Skin", "Minor Heal", "Water Breathing", "Double Jump",
        "Night Vision", "Swift Hands", "Fire Resistance",
        "Lightning Step", "Frost Touch", "Wind Burst", "Vampiric Touch",
        "Earth Grip", "Shadow Cloak",
        "Thunder Strike", "Ice Prison", "Regeneration", "Gravity Well", "Flame Wave",
        "Meteor Fall", "Time Freeze", "Dragon Aura", "Void Shift",
        "World Breaker", "Spatial Crack", "Reality Shift"
    );
    private final Map<String, Integer> rarityWeights = Map.of(
        "Common", 60, "Rare", 25, "Epic", 10, "Legendary", 4, "Mythical", 1
    );
    private final Map<String, String> skillRarity = new HashMap<>();
    private final Map<UUID, LinkedHashSet<String>> learned = new HashMap<>();
    private final Map<UUID, LinkedHashSet<String>> equipped = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<String, UUID> mythicalOwners = new HashMap<>();
    private NamespacedKey itemTypeKey, skillKey;
    private final Random random = new Random();

    @Override public void onEnable() {
        itemTypeKey = new NamespacedKey(this, "item_type");
        skillKey = new NamespacedKey(this, "skill");
        assignRarities();
        loadState();
        Bukkit.getPluginManager().registerEvents(this, this);
        registerTabletRecipe();
        getLogger().info("Skill Awakening v8.9 enabled. Created by Vgaming70.");
    }

    @Override public void onDisable() { saveState(); }

    private void assignRarities() {
        String[][] groups = {
            {"Common","Dash","Stone Skin","Minor Heal","Water Breathing","Double Jump","Night Vision","Swift Hands","Fire Resistance"},
            {"Rare","Lightning Step","Frost Touch","Wind Burst","Vampiric Touch","Earth Grip","Shadow Cloak"},
            {"Epic","Thunder Strike","Ice Prison","Regeneration","Gravity Well","Flame Wave"},
            {"Legendary","Meteor Fall","Time Freeze","Dragon Aura","Void Shift"},
            {"Mythical","World Breaker","Spatial Crack","Reality Shift"}
        };
        for (String[] group : groups) for (int i=1;i<group.length;i++) skillRarity.put(group[i],group[0]);
    }

    private ItemStack taggedItem(Material material, String name, String type, String skill) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, type);
        if (skill != null) meta.getPersistentDataContainer().set(skillKey, PersistentDataType.STRING, skill);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack tablet() { return taggedItem(Material.ENCHANTED_BOOK, "§dAncient Tablet", "tablet", null); }
    private ItemStack menuBook() { return taggedItem(Material.WRITTEN_BOOK, "§bSkill Menu Book", "menu", null); }
    private ItemStack skillBook(String skill) {
        ItemStack item = taggedItem(Material.BOOK, "§dAncient Skill Book: §f" + skill, "skill_book", skill);
        ItemMeta meta = item.getItemMeta();
        meta.setLore(List.of("§7Rarity: " + skillRarity.getOrDefault(skill,"Unknown"), "§8Use to learn this skill"));
        item.setItemMeta(meta);
        return item;
    }

    private void registerTabletRecipe() {
        ItemStack result = tablet();
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(this, "ancient_tablet"), result);
        recipe.shape("LLL", "EDE", "BBB");
        recipe.setIngredient('L', Material.LAPIS_LAZULI);
        recipe.setIngredient('E', Material.EXPERIENCE_BOTTLE);
        recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        recipe.setIngredient('B', Material.BOOK);
        Bukkit.addRecipe(recipe);
    }

    @EventHandler public void onInteract(PlayerInteractEvent event) {
        if (event.getItem() == null || !event.getItem().hasItemMeta()) return;
        ItemMeta meta = event.getItem().getItemMeta();
        String type = meta.getPersistentDataContainer().get(itemTypeKey, PersistentDataType.STRING);
        if (type == null) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        if (type.equals("tablet")) {
            String skill = rollSkill();
            if (skill == null) {
                p.sendMessage("§cAll Mythical skills have already been claimed; try again.");
                return;
            }
            p.getInventory().addItem(skillBook(skill));
            event.getItem().setAmount(event.getItem().getAmount()-1);
            p.sendMessage("§d✦ Awakening complete! §f" + skillRarity.get(skill) + " §7— §f" + skill);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            if ("Mythical".equals(skillRarity.get(skill))) {
                mythicalOwners.put(skill, p.getUniqueId());
                Bukkit.broadcastMessage("§5✦ MYTHICAL AWAKENING §d" + p.getName() + " §7obtained §f" + skill + "§7!");
                saveState();
            }
        } else if (type.equals("menu")) openMenu(p);
        else if (type.equals("skill_book")) {
            String skill = meta.getPersistentDataContainer().get(skillKey, PersistentDataType.STRING);
            if (skill == null) return;
            LinkedHashSet<String> set = learned.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashSet<>());
            if (set.add(skill)) {
                event.getItem().setAmount(event.getItem().getAmount()-1);
                p.sendMessage("§aLearned skill: §f" + skill);
                saveState();
            } else p.sendMessage("§cYou already know " + skill + ".");
        }
    }

    private String rollSkill() {
        List<String> pool = new ArrayList<>();
        for (String skill : allSkills) {
            if (!"Mythical".equals(skillRarity.get(skill)) || !mythicalOwners.containsKey(skill)) pool.add(skill);
        }
        if (pool.isEmpty()) return null;
        int total = rarityWeights.values().stream().mapToInt(Integer::intValue).sum();
        // Rarity is selected first; unavailable Mythical rolls are rerolled from available skills.
        for (int attempt=0; attempt<100; attempt++) {
            int n = random.nextInt(total), sum=0;
            String selectedRarity="Common";
            for (var e : rarityWeights.entrySet()) { sum += e.getValue(); if (n < sum) { selectedRarity=e.getKey(); break; } }
            final String rarityForFilter = selectedRarity;
            List<String> candidates = pool.stream().filter(skillName -> rarityForFilter.equals(skillRarity.get(skillName))).toList();
            if (!candidates.isEmpty()) return candidates.get(random.nextInt(candidates.size()));
        }
        return pool.get(random.nextInt(pool.size()));
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, MENU_TITLE);
        inv.setItem(11, taggedItem(Material.NETHER_STAR, "§aEquip / Manage Skills", "manage", null));
        inv.setItem(13, taggedItem(Material.BOOK, "§eSkill Archive", "archive", null));
        inv.setItem(15, taggedItem(Material.BLAZE_POWDER, "§cActivate Equipped Skills", "activate", null));
        if (p.isOp()) inv.setItem(22, taggedItem(Material.COMMAND_BLOCK, "§4Mythical Admin", "admin", null));
        p.openInventory(inv);
    }

    private void openManage(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, "§2Your Skills");
        int slot=0;
        for (String skill : learned.getOrDefault(p.getUniqueId(), new LinkedHashSet<>())) {
            if (slot>=45) break;
            ItemStack icon = taggedItem(Material.ENCHANTED_BOOK, "§f"+skill, "toggle", skill);
            List<String> lore = new ArrayList<>();
            lore.add("§7Rarity: "+skillRarity.get(skill));
            lore.add(equipped.getOrDefault(p.getUniqueId(),new LinkedHashSet<>()).contains(skill) ? "§aEquipped" : "§eClick to equip/unequip");
            ItemMeta m=icon.getItemMeta(); m.setLore(lore); icon.setItemMeta(m);
            inv.setItem(slot++, icon);
        }
        inv.setItem(49, taggedItem(Material.ARROW, "§cBack", "back", null));
        p.openInventory(inv);
    }

    private void openArchive(Player p) {
        Inventory inv=Bukkit.createInventory(null,54,"§eSkill Archive");
        int i=0;
        for(String s: learned.getOrDefault(p.getUniqueId(),new LinkedHashSet<>())) {
            if(i>=54) break;
            inv.setItem(i++, taggedItem(Material.BOOK,s,"archive_entry",null));
        }
        p.openInventory(inv);
    }

    private void openAdmin(Player p) {
        if(!p.isOp()) return;
        Inventory inv=Bukkit.createInventory(null,54,ADMIN_TITLE);
        int i=0;
        for(String s: List.of("World Breaker","Spatial Crack","Reality Shift")) {
            UUID owner=mythicalOwners.get(s);
            inv.setItem(i++, taggedItem(Material.NETHER_STAR,"§d"+s+" §7— "+(owner==null?"§aUnclaimed":"§eClaimed"),"admin_mythic_"+s,null));
        }
        inv.setItem(49,taggedItem(Material.BARRIER,"§cClose","close",null));
        p.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || e.getView().getTitle()==null) return;
        String title=e.getView().getTitle();
        if (!title.equals(MENU_TITLE) && !title.equals(ADMIN_TITLE) && !title.equals("§2Your Skills") && !title.equals("§eSkill Archive")) return;
        e.setCancelled(true);
        ItemStack item=e.getCurrentItem();
        if(item==null || !item.hasItemMeta()) return;
        String type=item.getItemMeta().getPersistentDataContainer().get(itemTypeKey,PersistentDataType.STRING);
        if(type==null) return;
        switch(type) {
            case "manage" -> openManage(p);
            case "archive" -> openArchive(p);
            case "activate" -> activateFirstEquipped(p);
            case "back" -> openMenu(p);
            case "admin" -> { if(p.isOp()) openAdmin(p); }
            case "close" -> p.closeInventory();
            case "toggle" -> toggleEquipped(p,item.getItemMeta().getPersistentDataContainer().get(skillKey,PersistentDataType.STRING));
            default -> {
                if(type.startsWith("admin_mythic_") && p.isOp()) {
                    String skill=type.substring("admin_mythic_".length());
                    mythicalOwners.remove(skill);
                    saveState(); openAdmin(p);
                    p.sendMessage("§eReleased world ownership for "+skill+".");
                }
            }
        }
    }

    private void toggleEquipped(Player p,String skill) {
        if(skill==null) return;
        LinkedHashSet<String> set=equipped.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>());
        if(set.remove(skill)) p.sendMessage("§eUnequipped "+skill+".");
        else if(set.size()<5) { set.add(skill); p.sendMessage("§aEquipped "+skill+"."); }
        else p.sendMessage("§cYou can equip only five skills.");
        saveState(); openManage(p);
    }

    private void activateFirstEquipped(Player p) {
        LinkedHashSet<String> set=equipped.getOrDefault(p.getUniqueId(),new LinkedHashSet<>());
        if(set.isEmpty()) { p.sendMessage("§cEquip a skill first."); return; }
        String skill=set.iterator().next();
        long now=System.currentTimeMillis();
        long until=cooldowns.computeIfAbsent(p.getUniqueId(),k->new HashMap<>()).getOrDefault(skill,0L);
        if(now<until) { p.sendMessage("§cCooldown: "+((until-now+999)/1000)+"s"); return; }
        useSkill(p,skill);
        long seconds=switch(skill) { case "World Breaker","Spatial Crack" -> 210; case "Reality Shift" -> 330; default -> 30; };
        cooldowns.get(p.getUniqueId()).put(skill,now+seconds*1000);
    }

    private void useSkill(Player p,String s) {
        switch(s) {
            case "Dash","Lightning Step","Spatial Crack" -> {
                Vector v=p.getLocation().getDirection().normalize().multiply(s.equals("Spatial Crack")?30:6);
                var dest=p.getLocation().add(v);
                if(dest.getBlock().isPassable() && dest.clone().add(0,1,0).getBlock().isPassable()) p.teleport(dest);
                else p.setVelocity(p.getLocation().getDirection().multiply(1.8));
            }
            case "Stone Skin","Ice Prison","Time Freeze","Reality Shift" -> p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,200, s.equals("Reality Shift")?4:1));
            case "Minor Heal" -> p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+4));
            case "Water Breathing" -> p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING,600,0));
            case "Night Vision" -> p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,600,0));
            case "Swift Hands" -> p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,600,0));
            case "Fire Resistance" -> p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,600,0));
            case "Shadow Cloak" -> p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,200,0));
            case "Regeneration" -> p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,300,1));
            case "Dragon Aura" -> p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH,300,1));
            case "Celestial Wings" -> p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING,400,0));
            case "Double Jump" -> p.sendMessage("§7Double Jump is a placeholder in this version.");
            default -> {
                for(Entity entity:p.getNearbyEntities(5,3,5)) if(entity instanceof org.bukkit.entity.LivingEntity living && entity!=p) {
                    if(s.equals("Wind Burst")) living.setVelocity(living.getLocation().toVector().subtract(p.getLocation().toVector()).normalize().multiply(1.5));
                    else if(s.equals("Frost Touch") || s.equals("Earth Grip")) living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,100,2));
                    else if(s.equals("Vampiric Touch")) { living.damage(4,p); p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+2)); }
                    else if(s.equals("Thunder Strike") || s.equals("Meteor Fall") || s.equals("World Breaker") || s.equals("Flame Wave")) living.damage(s.equals("Meteor Fall")?16:8,p);
                    else if(s.equals("Gravity Well")) living.setVelocity(p.getLocation().toVector().subtract(living.getLocation().toVector()).normalize().multiply(1.2));
                }
            }
        }
        p.getWorld().spawnParticle(Particle.PORTAL,p.getLocation().add(0,1,0),35,0.6,0.8,0.6,0.1);
        p.playSound(p.getLocation(),Sound.ENTITY_EVOKER_CAST_SPELL,1f,1.2f);
    }

    private void loadState() {
        if(!getDataFolder().exists()) getDataFolder().mkdirs();
        var cfg=getConfig();
        for(String skill:List.of("World Breaker","Spatial Crack","Reality Shift")) {
            String raw=cfg.getString("mythical."+skill);
            if(raw!=null) try { mythicalOwners.put(skill,UUID.fromString(raw)); } catch(IllegalArgumentException ignored) {}
        }
        for(String key:cfg.getKeys(false)) {
            if(!key.startsWith("players.")) continue;
        }
        for(String rawId:cfg.getConfigurationSection("players")==null?Set.<String>of():cfg.getConfigurationSection("players").getKeys(false)) {
            UUID id; try{id=UUID.fromString(rawId);}catch(IllegalArgumentException ex){continue;}
            learned.put(id,new LinkedHashSet<>(cfg.getStringList("players."+rawId+".learned")));
            equipped.put(id,new LinkedHashSet<>(cfg.getStringList("players."+rawId+".equipped")));
        }
    }

    private void saveState() {
        var cfg=getConfig();
        for(String skill:List.of("World Breaker","Spatial Crack","Reality Shift")) {
            UUID owner=mythicalOwners.get(skill);
            if(owner==null) cfg.set("mythical."+skill,null); else cfg.set("mythical."+skill,owner.toString());
        }
        for(UUID id:learned.keySet()) {
            cfg.set("players."+id+".learned",new ArrayList<>(learned.get(id)));
            cfg.set("players."+id+".equipped",new ArrayList<>(equipped.getOrDefault(id,new LinkedHashSet<>())));
        }
        saveConfig();
    }
}
