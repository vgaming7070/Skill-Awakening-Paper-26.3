# Skill Awakening v8.9 — PaperMC 26.3

Created by **Vgaming70**.

## Build on GitHub using Android

This repository includes `.github/workflows/build.yml`. After you upload/commit all
project files to the `main` branch, GitHub Actions runs the build automatically.

1. Open the repository on GitHub.
2. Tap **Actions**.
3. Open **Build Skill Awakening**.
4. Wait for the run to finish.
5. Open the successful run and download the artifact named
   `Skill-Awakening-Paper-26.3`.
6. Extract the artifact ZIP. The plugin `.jar` is inside.

## Local build

Requires Java 25 and Gradle 9.1:

```bash
gradle build
```

The JAR is written to `build/libs/`.

## Server compatibility

This is a server-side Paper plugin. Bedrock players can use it when joining the
same Paper server through a compatible Geyser setup. No plugin is installed on
the Bedrock client.

## Included in this source package

- 26 skill definitions and weighted rarity selection.
- Per-player learned skills, equipment slots and cooldown tracking.
- Ancient Tablet and Ancient Skill Book items.
- Skill Menu inventory interface.
- Three world-unique Mythical skills with global ownership persistence.
- OP-only admin inventory for viewing and releasing Mythical ownership.
- Ancient Tablet crafting recipe.
- Global announcement when a Mythical skill is obtained.
- Basic effects for the skills, using Paper/Bukkit APIs.

## Important testing notes

This is a rebuilt source package, not a verified compiled JAR. GitHub Actions must
successfully resolve the Paper 26.3 API dependency and compile it before installation.
The Paper 26.3 Maven build coordinate may need updating if the published build number
differs. Test on a backup server first.

The inventory interface uses vanilla Minecraft inventory menus rather than Bedrock
custom forms/textures. Double Jump remains a placeholder. Ability balance, teleport
safety, PvP drops, chest rewards, and Geyser presentation need live testing; this
starter rebuild does not claim those behaviours are fully ported.
