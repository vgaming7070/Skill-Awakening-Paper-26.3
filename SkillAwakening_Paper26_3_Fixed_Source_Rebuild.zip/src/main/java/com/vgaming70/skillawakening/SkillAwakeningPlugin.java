package com.vgaming70.skillawakening;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.util.Vector;

import java.util.*;

public final class SkillAwakeningPlugin extends JavaPlugin implements Listener {
    private static final String MAIN = "§5Skill Awakening";
    private static final String SKILLS = "§2Learned Skills";
    private static final String ARCHIVE = "§eSkill Archive / Withdraw";
    private static final String ADMIN = "§4Mythical Admin";
    private static final String[] MYTHICAL = {"World Breaker","Spatial Crack","Reality Shift"};

    private final LinkedHashMap<String,String> rarity = new LinkedHashMap<>();
    private final Map<UUID,LinkedHashSet<String>> learned = new HashMap<>();
    private final Map<UUID,LinkedHashSet<String>> equipped = new HashMap<>();
    private final Map<UUID,Map<String,Long>> cooldowns = new HashMap<>();
    private final Map<String,UUID> mythicalOwners = new HashMap<>();
    private final Random random = new Random();
    private NamespacedKey typeKey, skillKey;

    @Override public void onEnable() {
        typeKey=new NamespacedKey(this,"type"); skillKey=new NamespacedKey(this,"skill");
        add("Common","Dash","Stone Skin","Minor Heal","Water Breathing","Double Jump","Night Vision","Swift Hands","Fire Resistance");
        add("Rare","Lightning Step","Frost Touch","Wind Burst","Vampiric Touch","Earth Grip","Shadow Cloak");
        add("Epic","Thunder Strike","Ice Prison","Regeneration","Gravity Well","Flame Wave");
        add("Legendary","Meteor Fall","Time Freeze","Dragon Aura","Void Shift");
        add("Mythical",MYTHICAL);
        loadData();
        getServer().getPluginManager().registerEvents(this,this);
        registerRecipe(); // deliberately preserved from the previous plugin: LLL / EDE / BBB
        getLogger().info("Skill Awakening v8.9.1 enabled (creator: Vgaming70). Runtime verification still required.");
    }
    private void add(String tier,String... names){ for(String s:names) rarity.put(s,tier); }
    @Override public void onDisable(){saveData();}

    private ItemStack tagged(Material m,String display,String type,String skill){
        ItemStack it=new ItemStack(m); ItemMeta meta=it.getItemMeta(); meta.setDisplayName(display);
        meta.getPersistentDataContainer().set(typeKey,PersistentDataType.STRING,type);
        if(skill!=null) meta.getPersistentDataContainer().set(skillKey,PersistentDataType.STRING,skill);
        it.setItemMeta(meta); return it;
    }
    private ItemStack menuBook(){return tagged(Material.WRITTEN_BOOK,"§bSkill Awakening Menu","menu",null);}
    private ItemStack tablet(){return tagged(Material.ENCHANTED_BOOK,"§dAncient Tablet","tablet",null);}
    private ItemStack skillBook(String skill){
        ItemStack it=tagged(Material.BOOK,"§dAncient Skill Book: §f"+skill,"book",skill);
        ItemMeta m=it.getItemMeta();m.setLore(List.of("§7Rank: §f"+rarity.get(skill),"§8Use to learn skill"));it.setItemMeta(m);return it;
    }
    private void registerRecipe(){
        NamespacedKey key=new NamespacedKey(this,"ancient_tablet");
        Bukkit.removeRecipe(key);
        ShapedRecipe recipe=new ShapedRecipe(key,tablet());
        recipe.shape("LLL","EDE","BBB");
        recipe.setIngredient('L',Material.LAPIS_LAZULI);
        recipe.setIngredient('E',Material.EXPERIENCE_BOTTLE);
        recipe.setIngredient('D',Material.DIAMOND_BLOCK);
        recipe.setIngredient('B',Material.BOOK);
        Bukkit.addRecipe(recipe);
    }

    @EventHandler public void firstJoin(PlayerJoinEvent e){
        UUID id=e.getPlayer().getUniqueId();
        if(getConfig().getBoolean("players."+id+".starterGiven",false)) return;
        e.getPlayer().getInventory().addItem(menuBook(),tablet());
        getConfig().set("players."+id+".starterGiven",true);saveData();
        e.getPlayer().sendMessage("§dSkill Awakening §7— use your Skill Menu Book to manage skills.");
    }
    @EventHandler public void useItem(PlayerInteractEvent e){
        ItemStack item=e.getItem(); if(item==null||!item.hasItemMeta())return;
        String type=item.getItemMeta().getPersistentDataContainer().get(typeKey,PersistentDataType.STRING);
        if(type==null)return; e.setCancelled(true); Player p=e.getPlayer();
        switch(type){
            case "menu" -> openMain(p);
            case "tablet" -> roll(p,item);
            case "book" -> learnBook(p,item);
        }
    }
    private void learnBook(Player p,ItemStack item){
        String s=item.getItemMeta().getPersistentDataContainer().get(skillKey,PersistentDataType.STRING);
        if(s==null||!rarity.containsKey(s))return;
        var set=learned.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>());
        if(set.add(s)){consumeOne(item);p.sendMessage("§aLearned §f"+s+"§a!");saveData();}
        else p.sendMessage("§cAlready learned. Use the Archive to withdraw it first.");
    }
    private void consumeOne(ItemStack item){item.setAmount(item.getAmount()-1);}

    private String rollSkill(){
        // Tier weights: Common 60, Rare 25, Epic 10, Legendary 4, Mythical 1.
        int n=random.nextInt(100), tier=n<60?0:n<85?1:n<95?2:n<99?3:4;
        String chosenTier=new String[]{"Common","Rare","Epic","Legendary","Mythical"}[tier];
        List<String> candidates=new ArrayList<>();
        for(String s:rarity.keySet()) if(rarity.get(s).equals(chosenTier) && (!chosenTier.equals("Mythical")||!mythicalOwners.containsKey(s))) candidates.add(s);
        // Mythical tier unavailable: roll a non-mythical tier, without granting a claimed Mythical.
        if(candidates.isEmpty()){
            candidates.clear(); for(String s:rarity.keySet())if(!"Mythical".equals(rarity.get(s))) candidates.add(s);
        }
        return candidates.isEmpty()?null:candidates.get(random.nextInt(candidates.size()));
    }
    private void roll(Player p,ItemStack tabletItem){
        String s=rollSkill(); if(s==null){p.sendMessage("§cNo skills available.");return;}
        // Consume tablet only when a roll is awarded.
        consumeOne(tabletItem);p.getInventory().addItem(skillBook(s));
        p.playSound(p.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,1,1);
        p.sendMessage("§d✦ Roll: §f"+rarity.get(s)+" §7— §f"+s);
        if("Mythical".equals(rarity.get(s))){
            mythicalOwners.put(s,p.getUniqueId());
            Bukkit.broadcastMessage("§5✦ MYTHICAL SKILL §d"+p.getName()+" §7obtained the book for §f"+s+"§7!");
            saveData();
        }
    }

    private void openMain(Player p){
        Inventory inv=Bukkit.createInventory(null,27,MAIN);
        inv.setItem(10,tagged(Material.NETHER_STAR,"§aEquip / Manage","manage",null));
        inv.setItem(13,tagged(Material.BOOK,"§eSkill Archive (Withdraw)","archive",null));
        inv.setItem(16,tagged(Material.BLAZE_POWDER,"§cActivate skills","activate",null));
        if(p.isOp())inv.setItem(22,tagged(Material.COMMAND_BLOCK,"§4Mythical Admin","admin",null));
        p.openInventory(inv);
    }
    private void openManage(Player p){
        Inventory inv=Bukkit.createInventory(null,54,SKILLS); int i=0;
        Set<String> equip=equipped.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>());
        for(String s:learned.getOrDefault(p.getUniqueId(),new LinkedHashSet<>())){
            if(i>=45)break;
            ItemStack icon=tagged(Material.ENCHANTED_BOOK,"§f"+s,"toggle",s);
            ItemMeta m=icon.getItemMeta();m.setLore(List.of("§7Rank: "+rarity.get(s),equip.contains(s)?"§aEquipped":"§eTap to equip"));icon.setItemMeta(m);
            inv.setItem(i++,icon);
        }
        inv.setItem(49,tagged(Material.ARROW,"§cBack","back",null));p.openInventory(inv);
    }
    private void openArchive(Player p){
        Inventory inv=Bukkit.createInventory(null,54,ARCHIVE); int i=0;
        for(String s:learned.getOrDefault(p.getUniqueId(),new LinkedHashSet<>())){
            ItemStack icon=tagged(Material.BOOK,"§eWithdraw: §f"+s,"withdraw",s);
            ItemMeta m=icon.getItemMeta();m.setLore(List.of("§7Click to withdraw","§7Skill will be unequipped and returned as a book"));icon.setItemMeta(m);
            if(i<45)inv.setItem(i++,icon);
        }
        inv.setItem(49,tagged(Material.ARROW,"§cBack","back",null));p.openInventory(inv);
    }
    private void openAdmin(Player p){
        if(!p.isOp())return;
        Inventory inv=Bukkit.createInventory(null,27,ADMIN);
        for(int i=0;i<3;i++){String s=MYTHICAL[i];UUID owner=mythicalOwners.get(s);
            inv.setItem(10+i,tagged(Material.NETHER_STAR,"§d"+s+" §7"+(owner==null?"§aAVAILABLE":"§eCLAIMED"),"release",s));}
        inv.setItem(22,tagged(Material.BARRIER,"§cClose","close",null));p.openInventory(inv);
    }
    @EventHandler public void click(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        String title=e.getView().getTitle();
        if(!List.of(MAIN,SKILLS,ARCHIVE,ADMIN).contains(title))return;
        e.setCancelled(true);ItemStack it=e.getCurrentItem();if(it==null||!it.hasItemMeta())return;
        String t=it.getItemMeta().getPersistentDataContainer().get(typeKey,PersistentDataType.STRING);
        String s=it.getItemMeta().getPersistentDataContainer().get(skillKey,PersistentDataType.STRING);
        switch(t==null?"":t){
            case "manage" -> openManage(p); case "archive" -> openArchive(p); case "activate" -> activate(p);
            case "admin" -> {if(p.isOp())openAdmin(p);} case "back" -> openMain(p); case "close" -> p.closeInventory();
            case "toggle" -> {var eq=equipped.computeIfAbsent(p.getUniqueId(),k->new LinkedHashSet<>());
                if(s==null)return;if(eq.remove(s))p.sendMessage("§eUnequipped "+s);
                else if(eq.size()<5){eq.add(s);p.sendMessage("§aEquipped "+s);}else p.sendMessage("§cOnly five equipment slots.");
                saveData();openManage(p);}
            case "withdraw" -> {if(s!=null){learned.getOrDefault(p.getUniqueId(),new LinkedHashSet<>()).remove(s);
                equipped.getOrDefault(p.getUniqueId(),new LinkedHashSet<>()).remove(s);
                p.getInventory().addItem(skillBook(s));saveData();openArchive(p);p.sendMessage("§eWithdrawn "+s+"§e; it is now a physical book.");}}
            case "release" -> {if(p.isOp()&&s!=null){mythicalOwners.remove(s);saveData();openAdmin(p);p.sendMessage("§eReleased world uniqueness for "+s);}}
        }
    }

    private void activate(Player p){
        Set<String> eq=equipped.getOrDefault(p.getUniqueId(),new LinkedHashSet<>());
        if(eq.isEmpty()){p.sendMessage("§cEquip skills first.");return;}
        Inventory inv=Bukkit.createInventory(null,27,"§cChoose Skill to Activate");
        int slot=0;for(String s:eq)inv.setItem(slot++,tagged(Material.BLAZE_POWDER,"§c"+s,"cast",s));
        p.openInventory(inv);
    }
    @EventHandler public void castClick(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p)||!e.getView().getTitle().equals("§cChoose Skill to Activate"))return;
        e.setCancelled(true);ItemStack it=e.getCurrentItem();if(it==null||!it.hasItemMeta())return;
        String s=it.getItemMeta().getPersistentDataContainer().get(skillKey,PersistentDataType.STRING);if(s==null)return;
        p.closeInventory();useSkill(p,s);
    }
    private boolean cooldown(Player p,String skill,int sec){
        long now=System.currentTimeMillis(),until=cooldowns.computeIfAbsent(p.getUniqueId(),k->new HashMap<>()).getOrDefault(skill,0L);
        if(now<until){p.sendMessage("§cCooldown: "+((until-now+999)/1000)+"s");return false;}
        cooldowns.get(p.getUniqueId()).put(skill,now+sec*1000L);return true;
    }
    private void useSkill(Player p,String s){
        int cd=s.equals("World Breaker")||s.equals("Spatial Crack")?210:s.equals("Reality Shift")?330:30;
        if(!cooldown(p,s,cd))return;
        switch(s){
            case "Minor Heal" -> p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(),p.getHealth()+4));
            case "Stone Skin" -> p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,160,0));
            case "Reality Shift" -> {p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,200,9));p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,200,0));}
            case "Spatial Crack" -> {Location target=lookTarget(p,30);if(target!=null)p.teleport(target);p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,100,1));}
            case "World Breaker" -> {LivingEntity target=target(p,5);if(target!=null)target.damage(8,p);}
            case "Frost Touch" -> affectNearby(p,5,l->l.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,100,1)));
            case "Lightning Step" -> {Location t=lookTarget(p,8);if(t!=null)p.teleport(t);}
            case "Water Breathing" -> p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING,600,0));
            case "Night Vision" -> p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,600,0));
            case "Swift Hands" -> p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,600,0));
            case "Fire Resistance" -> p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,600,0));
            case "Regeneration" -> p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,300,1));
            case "Dragon Aura" -> p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH,300,1));
            case "Shadow Cloak" -> p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,200,0));
            case "Time Freeze" -> p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,100,1));
            case "Dash","Void Shift" -> p.setVelocity(p.getLocation().getDirection().multiply(1.7));
            case "Double Jump" -> p.setVelocity(new Vector(0,0.8,0));
            default -> affectNearby(p,5,l->{if(s.equals("Thunder Strike")||s.equals("Meteor Fall"))l.damage(s.equals("Meteor Fall")?16:8,p);});
        }
        p.getWorld().spawnParticle(Particle.PORTAL,p.getLocation().add(0,1,0),28,0.5,0.7,0.5,0.08);
        p.playSound(p.getLocation(),Sound.ENTITY_EVOKER_CAST_SPELL,1,1.1f);
    }
    private LivingEntity target(Player p,double range){
        return p.getNearbyEntities(range,range,range).stream().filter(e->e instanceof LivingEntity&&e!=p)
            .map(e->(LivingEntity)e).min(Comparator.comparingDouble(e->e.getLocation().distanceSquared(p.getLocation()))).orElse(null);
    }
    private void affectNearby(Player p,double r,java.util.function.Consumer<LivingEntity> action){
        for(Entity e:p.getNearbyEntities(r,r,r))if(e instanceof LivingEntity le&&e!=p)action.accept(le);
    }
    private Location lookTarget(Player p,int distance){
        Location origin=p.getEyeLocation();Vector d=origin.getDirection().normalize();
        for(int i=1;i<=distance*4;i++){Location l=origin.clone().add(d.multiply(0.25));d=origin.getDirection().normalize();
            if(!l.getBlock().isPassable())return l.clone().add(0,1,0);}
        Location fallback=p.getLocation().add(p.getLocation().getDirection().multiply(distance));return fallback;
    }

    @EventHandler public void pvpDrop(EntityDeathEvent e){
        if(!(e.getEntity() instanceof Player victim))return;
        Player killer=victim.getKiller();if(killer==null)return;
        var skills=learned.get(victim.getUniqueId());if(skills==null||skills.size()<=3)return;
        List<String> candidates=new ArrayList<>(skills);String lost=candidates.get(random.nextInt(candidates.size()));
        skills.remove(lost);equipped.getOrDefault(victim.getUniqueId(),new LinkedHashSet<>()).remove(lost);
        e.getDrops().add(skillBook(lost));saveData();victim.sendMessage("§cYou dropped a skill book: "+lost);
    }
    @EventHandler public void protectMenuOnDeath(PlayerDeathEvent e){
        e.getDrops().removeIf(it->isType(it,"menu")); // menu book is protected from death drops
    }
    private boolean isType(ItemStack it,String type){
        return it!=null&&it.hasItemMeta()&&type.equals(it.getItemMeta().getPersistentDataContainer().get(typeKey,PersistentDataType.STRING));
    }

    // Structure chest/tablet reward: small chance when a player opens a generated loot chest.
    // Bukkit's stable event surface does not expose every loot-generation path, so this
    // implementation uses a conservative open event and tags chests once per location.
    @EventHandler public void chestReward(PlayerInteractEvent e){
        if(e.getClickedBlock()==null||!e.getClickedBlock().getType().name().contains("CHEST")||e.getAction()!=Action.RIGHT_CLICK_BLOCK)return;
        if(random.nextDouble()>0.04)return;
        if(!(e.getClickedBlock().getState() instanceof org.bukkit.block.Container c))return;
        String key="rewarded."+e.getClickedBlock().getWorld().getName()+"."+e.getClickedBlock().getX()+"."+e.getClickedBlock().getY()+"."+e.getClickedBlock().getZ();
        if(getConfig().getBoolean(key,false))return;
        c.getInventory().addItem(tablet());getConfig().set(key,true);saveData();
        e.getPlayer().sendMessage("§dAn Ancient Tablet reward was found in this chest!");
    }

    private void loadData(){
        var c=getConfig();
        for(String s:MYTHICAL){String u=c.getString("mythical."+s);if(u!=null)try{mythicalOwners.put(s,UUID.fromString(u));}catch(Exception ignored){}}
        var sec=c.getConfigurationSection("players");if(sec==null)return;
        for(String raw:sec.getKeys(false)){UUID id;try{id=UUID.fromString(raw);}catch(Exception ex){continue;}
            learned.put(id,new LinkedHashSet<>(c.getStringList("players."+raw+".learned")));
            equipped.put(id,new LinkedHashSet<>(c.getStringList("players."+raw+".equipped")));}
    }
    private void saveData(){
        var c=getConfig();
        for(String s:MYTHICAL){UUID u=mythicalOwners.get(s);c.set("mythical."+s,u==null?null:u.toString());}
        for(UUID id:learned.keySet()){c.set("players."+id+".learned",new ArrayList<>(learned.get(id)));c.set("players."+id+".equipped",new ArrayList<>(equipped.getOrDefault(id,new LinkedHashSet<>())));}
        saveConfig();
    }
}
