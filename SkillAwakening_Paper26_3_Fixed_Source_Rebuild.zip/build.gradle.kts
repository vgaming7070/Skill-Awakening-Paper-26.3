plugins { java }

group = "com.vgaming70"
version = "8.9.1"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Paper 26.3 API coordinate may need adjustment to the published build.
    compileOnly("io.papermc.paper:paper-api:26.3.build.255-stable")
}

java { toolchain.languageVersion.set(JavaLanguageVersion.of(25)) }
tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}
