# Skill Awakening PaperMC — source rebuild (8.9.1)

Creator: Vgaming70

This is a rebuilt source package based on the provided 8.9.0 JAR and project specs.
The Ancient Tablet recipe was preserved from the JAR/source shown in this conversation:
`LLL / EDE / BBB` (L=Lapis Lazuli, E=Experience Bottle, D=Diamond Block, B=Book).

## Intended improvements
- Persistent learned/equipped progress and Mythical owner data
- First-join menu book and Ancient Tablet
- Five equipped skills; menu activation selector
- Skill book learning and withdrawal/unequip from archive
- Mythical world uniqueness and OP release menu
- Mythical global announcement
- PvP skill-book drop when victim has more than 3 learned skills
- Chest tablet bonus, once per chest location
- Basic skill effects, cooldowns, particles/sound

## Important
This rebuild is **not compiled or runtime-tested** here. Several APIs/behaviours may need adjustments after GitHub Actions builds against a real Paper 26.3 API and the plugin is tested on a backup server. Treat it as a test build, not a production release.
